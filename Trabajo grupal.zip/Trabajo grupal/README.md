# PROYECTO 2 - encriptador y desencriptador
Este es un proyecto que ha sido realizado por; Karla Pelaez, Samy Melgarejo y Alessandra Vidal. 
### Nuestra situación significativa fue:
Resolver el problema de aburrimiento y tener más privacidad, ya que nuestro propósito es de crear una manera de hablar con los demás no usando sólo el Español,
si no buscar nuevas formas de comunicación y sobre todo porque nuestra página te ayuda a Encriptar y a Desencriptar.
### Nuestro grupo objetivo son:
A los jóvenes y adolescentes que les gusta usar nuevas formas de comunicarse con sus amigos y compañeros.
### Nuestro producto final se basa en:
Este producto final te ayuda a usar otra manera de lenguaje que a su vez te brinda la privacidad de comunicación, teniendo la seguridad 
de que nadie se entere de lo que has escrito, a menos que sepan de la existencia de este proyecto.
### Nuestro producta funciona:
Funciona de dos maneras que es básicamente 2 en 1, ya que te ayuda a Encriptar que quiere decir que de tu texto en español te lo convierte
al código que elijas (como en Base 64) y a Desencriptar que es al contrario, esto te ayuda a tener cierto tipo de privacidad que sólo tú y 
las personas que quieras van a saber.
### Gracias.