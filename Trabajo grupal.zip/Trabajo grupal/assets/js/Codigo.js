open.addEventListener('click', () => {
    ventana.classList.add('show');
});
 
close.addEventListener('click', () => {
    ventana.classList.remove('show');
});

open1.addEventListener('click', () => {
    ventana1.classList.add('show');
});

close1.addEventListener('click', () => {
    ventana1.classList.remove('show');
});